import {describe,expect,it} from 'vitest'
import {addRookieMatch,generateMatchPlan,matchTimes,moveMatch,moveMatchTo,removeRookieMatch,setRookieTeamCount,toggleRookieMatches,validateMatchPlan} from './match-order-model'

describe('경기 순서 편집 모델',()=>{
 it('저장된 팀 수에 따라 일반 경기 기본 대진을 만든다',()=>{
  const three=generateMatchPlan(3)
  expect(three.matches).toHaveLength(11)
  expect(three.matches.map(match=>match.kind)).toEqual(['regular','regular','regular','rookie','regular','regular','regular','rookie','regular','regular','regular'])
  expect(three.matches.slice(0,3).map(match=>[match.home,match.away])).toEqual([['A','B'],['B','C'],['A','C']])
  expect(generateMatchPlan(4).matches).toHaveLength(8)
  expect(generateMatchPlan(4).matches.map(match=>match.kind)).toEqual(['rookie','regular','regular','regular','regular','regular','regular','rookie'])
 })

 it('신입팀 수에 맞는 대진을 추가하고 일반 경기 사이로 옮긴다',()=>{
  let plan=setRookieTeamCount(generateMatchPlan(3),3)
  plan=addRookieMatch(addRookieMatch(plan))
  expect(plan.matches.slice(-2).map(match=>[match.home,match.away])).toEqual([['R1','R3'],['R1','R2']])
  const rookie=plan.matches.at(-1)!
  plan=moveMatch(plan,rookie.id,-1)
  expect(plan.matches.at(-2)?.id).toBe(rookie.id)
  expect(matchTimes(plan,'13:00',20).at(-2)).toEqual({start:'16:40',end:'17:00'})
  plan=setRookieTeamCount(plan,2)
  expect(plan.matches.filter(match=>match.kind==='rookie').every(match=>match.home==='R1'&&match.away==='R2')).toBe(true)
  expect(removeRookieMatch(plan,rookie.id).matches).toHaveLength(12)
  expect(validateMatchPlan(plan,3)).toBe('')
 })

 it('신입 경기를 끄면 일반 경기만 남고 다시 켜면 라운드 사이 기본 배치로 복원한다',()=>{
  const off=toggleRookieMatches(generateMatchPlan(3),false)
  expect(off.matches).toHaveLength(9)
  expect(off.matches.every(match=>match.kind==='regular')).toBe(true)
  const on=toggleRookieMatches(off,true)
  expect(on.matches.filter(match=>match.kind==='rookie')).toHaveLength(2)
  expect(on.matches.filter(match=>match.kind==='rookie').map(match=>[match.home,match.away])).toEqual([['R1','R2'],['R1','R2']])
 })

 it('드래그 결과의 목표 인덱스로 경기 한 개를 이동한다',()=>{
  const plan=generateMatchPlan(3),rookie=plan.matches[3]
  const moved=moveMatchTo(plan,rookie.id,7)
  expect(moved.matches[7].id).toBe(rookie.id)
  expect(moved.matches).toHaveLength(plan.matches.length)
  expect(plan.matches[3].id).toBe(rookie.id)
 })

 it('다른 팀 수나 허용되지 않은 대진은 저장하지 않는다',()=>{
  const plan=generateMatchPlan(3)
  expect(validateMatchPlan(plan,4)).not.toBe('')
  expect(validateMatchPlan({...plan,matches:[{...plan.matches[0],away:'D'},...plan.matches.slice(1)]},3)).not.toBe('')
 })
})
