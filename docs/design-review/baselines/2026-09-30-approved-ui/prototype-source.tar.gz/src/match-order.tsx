import {useEffect,useRef,useState,type PointerEvent as ReactPointerEvent,type KeyboardEvent as ReactKeyboardEvent} from 'react'
import {createPortal} from 'react-dom'
import {Check,GripVertical,Plus,Trash2,Pencil,Save} from 'lucide-react'
import {Button} from '@/components/ui/button'
import {Switch} from '@/components/ui/switch'
import {Select,SelectTrigger,SelectValue,SelectContent,SelectItem} from '@/components/ui/select'
import {Table,TableHeader,TableBody,TableRow,TableHead,TableCell} from '@/components/ui/table'
import {addRookieMatch,generateMatchPlan,matchTimes,moveMatch,moveMatchTo,removeRookieMatch,rookiePairOptions,setRookieMatchPair,setRookieTeamCount,toggleRookieMatches,type MatchPlan} from './match-order-model'
import {rosterErrorMessage,type RosterCommandResult} from './roster-state'
import './match-order.css'

const name=(id:string)=>id.startsWith('R')?`신입 ${id.slice(1)}팀`:`${id}팀`
const minutes=(time:string)=>{const [hour,minute]=time.split(':').map(Number);return hour*60+minute}

export function MatchOrder({teamCount,start,plan,onEdit}:{teamCount:number;start:string;plan?:MatchPlan;onEdit?:()=>void}){
 const times=plan?matchTimes(plan,start):[]
 return <section className="match-order-section" aria-label="경기 순서">
  <div className="section-heading match-heading"><div><h2>경기 순서</h2><span>{teamCount}팀 · 경기당 20분</span></div>{onEdit&&<Button size="sm" variant="outline" onClick={onEdit} aria-label="경기 순서 수정"><Pencil/>수정</Button>}</div>
  {!plan?<p className="muted">팀편성을 저장하면 경기 순서가 표시됩니다.</p>:<div className="match-schedule"><Table><TableHeader><TableRow><TableHead>순서</TableHead><TableHead>시간</TableHead><TableHead>대진</TableHead></TableRow></TableHeader><TableBody>{plan.matches.map((match,index)=><TableRow key={match.id} className={match.kind==='rookie'?'rookie-game':''}><TableCell className="game-number">{index+1}</TableCell><TableCell><time>{times[index].start}–{times[index].end}</time></TableCell><TableCell><div className="game-pair"><strong>{name(match.home)}</strong><span>vs</span><strong>{name(match.away)}</strong></div></TableCell></TableRow>)}</TableBody></Table></div>}
 </section>
}

type EditorProps={teamCount:number;start:string;end:string;baseline?:MatchPlan;revision:number;actionHost:HTMLElement|null;onSave:(plan:MatchPlan,expectedRevision:number)=>RosterCommandResult;onCancel:()=>void;onSaved?:()=>void;onDirty:(dirty:boolean)=>void}
type DragState={id:string;x:number;y:number;overId:string|null;native?:boolean}
export function MatchOrderEditor({teamCount,start,end,baseline,revision,actionHost,onSave,onCancel,onSaved,onDirty}:EditorProps){
 const initial=baseline?.teamCount===teamCount?baseline:generateMatchPlan(teamCount)
 const [working,setWorking]=useState<MatchPlan>(()=>structuredClone(initial)),[error,setError]=useState(''),[drag,setDrag]=useState<DragState|null>(null)
 const pointer=useRef<{id:string;pointerId:number;x:number;y:number;overId:string|null}|null>(null)
 const dirty=JSON.stringify(working)!==JSON.stringify(initial)
 useEffect(()=>onDirty(dirty),[dirty,onDirty])
 useEffect(()=>()=>onDirty(false),[onDirty])
 const times=matchTimes(working,start),rookies=working.matches.some(match=>match.kind==='rookie')
 const overflow=minutes(start)+working.matches.length*20>minutes(end)
 function update(plan:MatchPlan){setWorking(plan);setError('')}
 function save(){const result=onSave(working,revision);if(!result.ok){setError(rosterErrorMessage(result.code));return}onDirty(false);onSaved?.()}
 function track(x:number,y:number){if(!pointer.current)return;pointer.current.x=x;pointer.current.y=y;const el=document.elementFromPoint?.(x,y)?.closest<HTMLElement>('[data-match-id]');if(el?.dataset.matchId)pointer.current.overId=el.dataset.matchId;setDrag({...pointer.current});if(y<96)window.scrollBy(0,-12);else if(y>window.innerHeight-80)window.scrollBy(0,12)}
 function startDrag(e:ReactPointerEvent<HTMLButtonElement>,id:string){if(e.pointerType==='mouse')return;e.preventDefault();e.currentTarget.setPointerCapture(e.pointerId);pointer.current={id,pointerId:e.pointerId,x:e.clientX,y:e.clientY,overId:id};setDrag({...pointer.current})}
 function moveDrag(e:ReactPointerEvent<HTMLButtonElement>){if(pointer.current?.pointerId===e.pointerId)track(e.clientX,e.clientY)}
 function finishDrag(e:ReactPointerEvent<HTMLButtonElement>){const current=pointer.current;if(!current||current.pointerId!==e.pointerId)return;track(e.clientX,e.clientY);const target=pointer.current?.overId;pointer.current=null;setDrag(null);if(target){const index=working.matches.findIndex(match=>match.id===target);if(index>=0)update(moveMatchTo(working,current.id,index))}}
 function keyMove(e:ReactKeyboardEvent<HTMLButtonElement>,id:string){if(e.key!=='ArrowUp'&&e.key!=='ArrowDown')return;e.preventDefault();update(moveMatch(working,id,e.key==='ArrowUp'?-1:1))}
 const actions=<><Button variant="outline" size="sm" onClick={onCancel}>취소</Button><Button size="sm" onClick={save}><Save/>저장</Button></>
 return <section className="match-order-editor" aria-label="경기 순서 수정">
  {!actionHost&&<div className="match-editor-actions-top">{actions}</div>}
  {actionHost&&createPortal(actions,actionHost)}
  <div className="match-editor-summary"><p>{teamCount}팀 · 일반 경기 {working.matches.filter(match=>match.kind==='regular').length}경기 · 신입 경기 {working.matches.filter(match=>match.kind==='rookie').length}경기</p><small>한 라운드에서 모든 팀이 서로 한 번씩 경기합니다. 손잡이를 끌어 순서를 바꾸세요.</small></div>
  <div className="match-editor-toolbar"><div className="match-rookie-toggle"><label htmlFor="rookie-games">신입 경기 포함</label><Switch id="rookie-games" aria-label="신입 경기 포함" checked={rookies} onCheckedChange={enabled=>update(toggleRookieMatches(working,enabled))}/></div>{rookies&&<><label htmlFor="rookie-team-count">신입팀</label><Select value={String(working.rookieTeamCount)} onValueChange={value=>update(setRookieTeamCount(working,Number(value)))}><SelectTrigger id="rookie-team-count" aria-label="신입팀 수"><SelectValue/></SelectTrigger><SelectContent>{[2,3,4].map(count=><SelectItem key={count} value={String(count)}>{count}팀</SelectItem>)}</SelectContent></Select><Button variant="outline" size="sm" onClick={()=>update(addRookieMatch(working))}><Plus/>경기 추가</Button></>}</div>
  <ol className="match-editor-list" aria-label="경기 순서 편집">{working.matches.map((match,index)=><li key={match.id} data-match-id={match.id} className={`${match.kind==='rookie'?'rookie-game':''} ${drag?.id===match.id?'dragging':''} ${drag?.overId===match.id&&drag.id!==match.id?'drop-target':''}`} onDragOver={e=>{e.preventDefault();if(drag)setDrag({...drag,overId:match.id})}} onDrop={e=>{e.preventDefault();const id=e.dataTransfer.getData('text/plain');update(moveMatchTo(working,id,index));setDrag(null)}}><div className="match-editor-number"><strong>{index+1}</strong><span>{times[index].start}–{times[index].end}</span></div><div className="match-editor-pair">{match.kind==='regular'?<><small>일반 경기</small><strong>{name(match.home)} <span>vs</span> {name(match.away)}</strong></>:<><small>신입 경기</small><Select value={`${match.home}-${match.away}`} onValueChange={value=>{const [home,away]=value.split('-');update(setRookieMatchPair(working,match.id,home,away))}}><SelectTrigger aria-label={`${index+1}번째 신입 경기 대진`}><SelectValue/></SelectTrigger><SelectContent>{rookiePairOptions(working.rookieTeamCount).map(([home,away])=><SelectItem value={`${home}-${away}`} key={`${home}-${away}`}>{name(home)} vs {name(away)}</SelectItem>)}</SelectContent></Select></>}</div><div className="match-editor-move"><Button variant="ghost" size="icon" className="match-drag-handle" draggable aria-label={`${index+1}번째 경기 드래그하여 이동`} aria-keyshortcuts="ArrowUp ArrowDown" onDragStart={e=>{e.dataTransfer.effectAllowed='move';e.dataTransfer.setData('text/plain',match.id);setDrag({id:match.id,x:e.clientX,y:e.clientY,overId:match.id,native:true})}} onDragEnd={()=>setDrag(null)} onPointerDown={e=>startDrag(e,match.id)} onPointerMove={moveDrag} onPointerUp={finishDrag} onPointerCancel={()=>{pointer.current=null;setDrag(null)}} onKeyDown={e=>keyMove(e,match.id)}><GripVertical/></Button>{match.kind==='rookie'&&<Button variant="ghost" size="icon" aria-label={`${index+1}번째 신입 경기 삭제`} onClick={()=>update(removeRookieMatch(working,match.id))}><Trash2/></Button>}</div></li>)}</ol>
  {drag&&!drag.native&&<div className="match-drag-preview" style={{left:drag.x,top:drag.y}} aria-hidden="true">{name(working.matches.find(match=>match.id===drag.id)?.home??'')} vs {name(working.matches.find(match=>match.id===drag.id)?.away??'')}</div>}
  {overflow&&<p className="match-overflow" role="alert">마지막 경기 종료가 {times.at(-1)?.end}입니다. 운동 종료 시각({end})을 넘습니다. 경기 수를 확인하세요.</p>}
  {error&&<p className="match-error" role="alert">{error}</p>}
 </section>
}
