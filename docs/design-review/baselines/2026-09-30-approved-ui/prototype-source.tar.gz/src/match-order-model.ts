export type MatchGame={id:string;kind:'regular'|'rookie';home:string;away:string}
export type MatchPlan={teamCount:number;rookieTeamCount:number;matches:MatchGame[]}

export const regularPairs:Record<number,[string,string][]>= {
 3:[['A','B'],['B','C'],['A','C']],
 4:[['A','B'],['C','D'],['A','C'],['B','D'],['A','D'],['B','C']],
}

export function generateMatchPlan(teamCount:number):MatchPlan{
 const pairs=regularPairs[teamCount]??[]
 const rounds=teamCount===3?3:1
 const base:MatchPlan={teamCount,rookieTeamCount:2,matches:Array.from({length:pairs.length*rounds},(_,index)=>{
  const [home,away]=pairs[index%pairs.length]
  return {id:`regular-${index+1}`,kind:'regular' as const,home,away}
 })}
 return toggleRookieMatches(base,true)
}

export function toggleRookieMatches(plan:MatchPlan,enabled:boolean):MatchPlan{
 const regular=plan.matches.filter(match=>match.kind==='regular')
 if(!enabled)return {...plan,matches:regular}
 if(plan.matches.some(match=>match.kind==='rookie'))return plan
 const pairs=rookiePairs(plan.rookieTeamCount)
 if(plan.teamCount===4&&regular.length){
  const [home,away]=pairs[0]
  return {...plan,matches:[{id:'rookie-1',kind:'rookie',home,away},...regular,{id:'rookie-2',kind:'rookie',home,away}]}
 }
 const roundSize=plan.teamCount===3?3:regular.length
 const matches:MatchGame[]=[]
 for(let index=0;index<regular.length;index++){
  matches.push(regular[index])
  if((index+1)%roundSize===0&&index<regular.length-1){
   const rookieIndex=matches.filter(match=>match.kind==='rookie').length
   const [home,away]=pairs[rookieIndex%pairs.length]
   matches.push({id:`rookie-${rookieIndex+1}`,kind:'rookie',home,away})
  }
 }
 return {...plan,matches}
}

const rookiePairs=(count:number):[string,string][]=>{
 const patterns:Record<number,[number,number][]>={2:[[1,2]],3:[[1,2],[2,3],[1,3]],4:[[1,2],[3,4],[1,3],[2,4],[1,4],[2,3]]}
 return (patterns[count]??[]).map(([home,away])=>[`R${home}`,`R${away}`])
}
export const rookiePairOptions=(count:number)=>rookiePairs(count)

export function setRookieTeamCount(plan:MatchPlan,count:number):MatchPlan{
 if(!Number.isInteger(count)||count<2||count>4)return plan
 const pairs=rookiePairs(count)
 let index=0
 return {...plan,rookieTeamCount:count,matches:plan.matches.map(match=>{
  if(match.kind!=='rookie')return match
  const [home,away]=pairs[index++%pairs.length]
  return {...match,home,away}
 })}
}

export function addRookieMatch(plan:MatchPlan):MatchPlan{
 const pairs=rookiePairs(plan.rookieTeamCount)
 const count=plan.matches.filter(match=>match.kind==='rookie').length
 const next=1+Math.max(0,...plan.matches.filter(match=>match.id.startsWith('rookie-')).map(match=>Number(match.id.slice(7))||0))
 const [home,away]=pairs[count%pairs.length]
 return {...plan,matches:[...plan.matches,{id:`rookie-${next}`,kind:'rookie',home,away}]}
}

export function setRookieMatchPair(plan:MatchPlan,id:string,home:string,away:string):MatchPlan{
 if(home===away||!rookiePairs(plan.rookieTeamCount).some(pair=>pair.includes(home)&&pair.includes(away)))return plan
 return {...plan,matches:plan.matches.map(match=>match.id===id&&match.kind==='rookie'?{...match,home,away}:match)}
}

export function moveMatch(plan:MatchPlan,id:string,direction:-1|1):MatchPlan{
 const index=plan.matches.findIndex(match=>match.id===id),other=index+direction
 if(index<0||other<0||other>=plan.matches.length)return plan
 const matches=[...plan.matches]
 ;[matches[index],matches[other]]=[matches[other],matches[index]]
 return {...plan,matches}
}

export function moveMatchTo(plan:MatchPlan,id:string,toIndex:number):MatchPlan{
 const from=plan.matches.findIndex(match=>match.id===id)
 if(from<0||!Number.isInteger(toIndex)||toIndex<0||toIndex>=plan.matches.length||from===toIndex)return plan
 const matches=[...plan.matches]
 const [moved]=matches.splice(from,1)
 matches.splice(toIndex,0,moved)
 return {...plan,matches}
}

export function removeRookieMatch(plan:MatchPlan,id:string):MatchPlan{
 return {...plan,matches:plan.matches.filter(match=>match.id!==id||match.kind!=='rookie')}
}

export function matchTimes(plan:MatchPlan,start:string,duration=20){
 const [hour,minute]=start.split(':').map(Number)
 const format=(minutes:number)=>`${String(Math.floor(minutes/60)%24).padStart(2,'0')}:${String(minutes%60).padStart(2,'0')}`
 return plan.matches.map((_,index)=>({start:format(hour*60+minute+index*duration),end:format(hour*60+minute+(index+1)*duration)}))
}

export function validateMatchPlan(plan:MatchPlan,teamCount:number):string{
 if(plan.teamCount!==teamCount||!regularPairs[teamCount])return '저장된 팀 수에 맞는 경기 순서를 다시 생성해 주세요.'
 if(!Number.isInteger(plan.rookieTeamCount)||plan.rookieTeamCount<2||plan.rookieTeamCount>4)return '신입팀 수를 2~4팀으로 정해 주세요.'
 if(!plan.matches.length||new Set(plan.matches.map(match=>match.id)).size!==plan.matches.length)return '경기 순서의 중복이나 빈 목록을 확인해 주세요.'
 const regular=new Set(regularPairs[teamCount].flat())
 const rookies=new Set(Array.from({length:plan.rookieTeamCount},(_,index)=>`R${index+1}`))
 if(plan.matches.some(match=>match.home===match.away||match.kind==='regular'&&(!regular.has(match.home)||!regular.has(match.away))||match.kind==='rookie'&&(!rookies.has(match.home)||!rookies.has(match.away))))return '경기 대진에 없는 팀이 포함되어 있어요.'
 return ''
}
