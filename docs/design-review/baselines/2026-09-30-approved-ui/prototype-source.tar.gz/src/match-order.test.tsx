import {afterEach,describe,expect,it,vi} from 'vitest'
import {cleanup,fireEvent,render,screen,within} from '@testing-library/react'
import {MatchOrder,MatchOrderEditor} from './match-order'
import {generateMatchPlan,type MatchPlan} from './match-order-model'

afterEach(cleanup)
const base=generateMatchPlan(3)
const props={teamCount:3,start:'13:00',end:'17:00',baseline:base,revision:4,onSave:vi.fn(()=>({ok:true as const,next:{} as never})),onCancel:vi.fn(),onDirty:vi.fn(),actionHost:null}

describe('경기 순서 수정 화면',()=>{
 it('신입 경기를 끄고 저장하면 일반 경기만 남으며 공개 단계가 없다',()=>{
  const onSave=vi.fn(()=>({ok:true as const,next:{} as never}))
  render(<MatchOrderEditor {...props} onSave={onSave}/>)
  fireEvent.click(screen.getByRole('switch',{name:'신입 경기 포함'}))
  expect(screen.getByRole('list',{name:'경기 순서 편집'}).querySelectorAll('li')).toHaveLength(9)
  fireEvent.click(screen.getByRole('button',{name:'저장'}))
  const [plan,revision]=onSave.mock.calls[0] as unknown as [MatchPlan,number]
  expect([plan.matches.length,revision]).toEqual([9,4])
  expect(screen.queryByRole('button',{name:'공개'})).toBeNull()
 })
 it('신입팀 수를 바꾸고 라운드 사이 경기의 순서를 이동해 저장한다',()=>{
  const onSave=vi.fn(()=>({ok:true as const,next:{} as never}))
  render(<MatchOrderEditor {...props} onSave={onSave}/>)
  const list=screen.getByRole('list',{name:'경기 순서 편집'})
  expect(within(list).getAllByText('신입 경기')).toHaveLength(2)
  fireEvent.keyDown(screen.getByRole('button',{name:'4번째 경기 드래그하여 이동'}),{key:'ArrowUp'})
  expect(list.querySelectorAll('li')[2].getAttribute('data-match-id')).toBe('rookie-1')
  fireEvent.click(screen.getByRole('button',{name:'저장'}))
  const [plan]=onSave.mock.calls[0] as unknown as [MatchPlan]
  expect(plan.matches[2].id).toBe('rookie-1')
 })
 it('모바일 터치로 손잡이를 옮기면 놓은 경기 앞으로 순서를 변경한다',()=>{
  const onSave=vi.fn(()=>({ok:true as const,next:{} as never}))
  render(<MatchOrderEditor {...props} onSave={onSave}/>)
  const list=screen.getByRole('list',{name:'경기 순서 편집'})
  const handle=screen.getByRole('button',{name:'4번째 경기 드래그하여 이동'})
  const target=list.querySelectorAll('li')[1]
  Object.defineProperty(handle,'setPointerCapture',{value:vi.fn(),configurable:true})
  Object.defineProperty(document,'elementFromPoint',{value:vi.fn(()=>target),configurable:true})
  fireEvent.pointerDown(handle,{pointerId:7,pointerType:'touch',clientX:200,clientY:400})
  fireEvent.pointerMove(handle,{pointerId:7,pointerType:'touch',clientX:200,clientY:300})
  fireEvent.pointerUp(handle,{pointerId:7,pointerType:'touch',clientX:200,clientY:300})
  expect(list.querySelectorAll('li')[1].getAttribute('data-match-id')).toBe('rookie-1')
  fireEvent.click(screen.getByRole('button',{name:'저장'}))
  const [plan]=onSave.mock.calls[0] as unknown as [MatchPlan]
  expect(plan.matches[1].id).toBe('rookie-1')
  Reflect.deleteProperty(document,'elementFromPoint')
 })
 it('공개된 순서와 수정 진입 버튼만 상세에서 보이고 별도 편집 컨트롤은 없다',()=>{
  const onEdit=vi.fn()
  render(<MatchOrder teamCount={3} start="13:00" plan={base} onEdit={onEdit}/>)
  fireEvent.click(screen.getByRole('button',{name:'경기 순서 수정'}))
  expect(onEdit).toHaveBeenCalledOnce()
  expect(screen.queryByRole('switch',{name:'신입 경기 포함'})).toBeNull()
 })
 it('경기 수가 종료 시각을 넘으면 저장 전에 경고한다',()=>{
  render(<MatchOrderEditor {...props} end="16:00"/>)
  expect(screen.getByRole('alert').textContent).toContain('운동 종료 시각(16:00)을 넘습니다')
 })
})
